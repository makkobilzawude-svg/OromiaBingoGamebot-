OROMIA BINGO — Qajeelfama gabaabaa

Faayilota:
- public/index.html: fuula game
- public/style.css: dizaayinii
- public/app.js: loojikii Bingo
- server.js: backend Node.js
- package.json: dependencies fi start script

Render irratti:
1. Repository GitHub kee keessatti faayilota kana olkaa'i; folder public waliin.
2. Render > New > Web Service > repository filadhu.
3. Build Command: npm install
4. Start Command: npm start
5. Deploy booda URL server argatta.

Hubachiisa: Kun demo/prototype qofa. Kaffaltii dhugaa, wallet, yookaan tapha qarshii dhugaa hin qabu. Seera biyya kee fi nageenya mirkaneessi.
